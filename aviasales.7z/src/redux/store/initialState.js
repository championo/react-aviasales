export const initialState = {
  tickets: [],
  selectedCurrency: 'rub',
  filterStops: [],
  filterResults: [],
  currencies: null
}